"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import type { Stream } from "@/lib/types";
import { addDays, cn, startOfDay, startOfWeek } from "@/lib/utils";
import MonthView from "@/components/schedule/MonthView";
import WeekView from "@/components/schedule/WeekView";
import StreamItem from "@/components/schedule/StreamItem";
import StreamModal, { type StreamDraft } from "@/components/schedule/StreamModal";

type View = "week" | "month";
type ModalState = { stream?: Stream; date?: Date } | null;

export default function SchedulePage() {
  const { ready, streams, games, addStream, updateStream, setStreams } = useStore();
  const [view, setView] = useState<View>("week");
  const [cursor, setCursor] = useState(() => new Date());
  const [selected, setSelected] = useState(() => startOfDay(new Date()));
  const [modal, setModal] = useState<ModalState>(null);

  const byDay = useMemo(() => {
    const m = new Map<string, Stream[]>();
    streams.forEach((s) => {
      const k = new Date(s.start).toDateString();
      m.set(k, [...(m.get(k) ?? []), s]);
    });
    m.forEach((l) => l.sort((a, b) => +new Date(a.start) - +new Date(b.start)));
    return m;
  }, [streams]);

  const nav = (dir: number) => setCursor((c) => (view === "week" ? addDays(c, 7 * dir) : new Date(c.getFullYear(), c.getMonth() + dir, 1)));

  const title = (() => {
    if (view === "month") return cursor.toLocaleDateString("ru-RU", { month: "long", year: "numeric" });
    const s = startOfWeek(cursor);
    const e = addDays(s, 6);
    const f = (d: Date) => d.toLocaleDateString("ru-RU", { day: "numeric", month: "short" });
    return `${f(s)} – ${f(e)}`;
  })();

  const save = (d: StreamDraft) => {
    if (modal?.stream) updateStream(modal.stream.id, d);
    else addStream(d);
    setModal(null);
  };

  const selectedList = byDay.get(selected.toDateString()) ?? [];

  if (!ready) return <div className="card h-64 animate-pulse" />;

  return (
    <div className="space-y-5">
      <header className="flex flex-wrap items-center gap-3">
        <h1 className="mr-auto text-2xl font-bold">Расписание</h1>
        <button className="btn btn-primary" onClick={() => setModal({ date: selected })}>+ Стрим</button>
      </header>

      <div className="flex flex-wrap items-center gap-2">
        <div className="flex rounded-xl border border-line p-0.5">
          {(["week", "month"] as View[]).map((v) => (
            <button key={v} onClick={() => setView(v)}
              className={cn("rounded-lg px-3 py-1.5 text-sm font-medium transition", view === v ? "bg-accent text-white" : "text-muted hover:text-white")}>
              {v === "week" ? "Неделя" : "Месяц"}
            </button>
          ))}
        </div>
        <div className="ml-auto flex items-center gap-1">
          <button className="btn !px-3" onClick={() => nav(-1)} aria-label="Назад">‹</button>
          <button className="btn" onClick={() => { setCursor(new Date()); setSelected(startOfDay(new Date())); }}>Сегодня</button>
          <button className="btn !px-3" onClick={() => nav(1)} aria-label="Вперёд">›</button>
        </div>
        <h2 className="w-full text-lg font-semibold capitalize">{title}</h2>
      </div>

      {view === "week" ? (
        <WeekView cursor={cursor} byDay={byDay} onAdd={(d) => setModal({ date: d })} onOpen={(s) => setModal({ stream: s })} />
      ) : (
        <>
          <MonthView cursor={cursor} selected={selected} byDay={byDay} onSelect={setSelected} onOpen={(s) => setModal({ stream: s })} />
          <section className="card">
            <div className="flex items-center justify-between">
              <h3 className="h-section">{selected.toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long" })}</h3>
              <button className="btn" onClick={() => setModal({ date: selected })}>+ Добавить</button>
            </div>
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {selectedList.length === 0 ? <p className="text-sm text-muted">В этот день стримов нет.</p> : selectedList.map((s) => <StreamItem key={s.id} stream={s} onClick={() => setModal({ stream: s })} />)}
            </div>
          </section>
        </>
      )}

      {modal && (
        <StreamModal
          key={modal.stream?.id ?? "new"}
          stream={modal.stream}
          defaultDate={modal.date}
          gameTitles={games.map((g) => g.title)}
          onSave={save}
          onDelete={modal.stream ? () => { setStreams((p) => p.filter((s) => s.id !== modal.stream!.id)); setModal(null); } : undefined}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  );
}
