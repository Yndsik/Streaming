import NextStream from "@/components/dashboard/NextStream";
import IdeasWidget from "@/components/dashboard/IdeasWidget";
import GamesWidget from "@/components/dashboard/GamesWidget";

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-2xl font-bold sm:text-3xl">Главная</h1>
        <p className="mt-1 text-sm text-muted">Всё для следующего стрима в одном месте</p>
      </header>
      <NextStream />
      <div className="grid gap-6 lg:grid-cols-2">
        <IdeasWidget />
        <GamesWidget />
      </div>
    </div>
  );
}
