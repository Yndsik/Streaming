"use client";

import { useMemo, useState } from "react";
import { useStore } from "@/lib/store";
import { PRIORITY_LABEL, type Idea, type Priority } from "@/lib/types";
import { cn, uid } from "@/lib/utils";
import IdeaModal, { type IdeaDraft } from "@/components/ideas/IdeaModal";

const ORDER: Record<Priority, number> = { high: 0, medium: 1, low: 2 };
const BADGE: Record<Priority, string> = {
  high: "bg-red-500/15 text-red-400",
  medium: "bg-amber-400/15 text-amber-300",
  low: "bg-zinc-500/20 text-zinc-300",
};

export default function IdeasPage() {
  const { ready, ideas, streams, setIdeas } = useStore();
  const [q, setQ] = useState("");
  const [prio, setPrio] = useState<Priority | "all">("all");
  const [tag, setTag] = useState<string | null>(null);
  const [modal, setModal] = useState<{ idea?: Idea } | null>(null);

  const allTags = useMemo(() => [...new Set(ideas.flatMap((i) => i.tags))].sort(), [ideas]);

  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return ideas
      .filter((i) => (prio === "all" || i.priority === prio) && (!tag || i.tags.includes(tag)))
      .filter((i) => !s || i.title.toLowerCase().includes(s) || i.description?.toLowerCase().includes(s))
      .sort((a, b) => ORDER[a.priority] - ORDER[b.priority] || +new Date(b.createdAt) - +new Date(a.createdAt));
  }, [ideas, q, prio, tag]);

  const save = (d: IdeaDraft) => {
    if (modal?.idea) setIdeas((p) => p.map((i) => (i.id === modal.idea!.id ? { ...i, ...d } : i)));
    else setIdeas((p) => [{ id: uid(), createdAt: new Date().toISOString(), ...d }, ...p]);
    setModal(null);
  };

  if (!ready) return <div className="card h-64 animate-pulse" />;

  return (
    <div className="space-y-5">
      <header className="flex items-center gap-3">
        <div className="mr-auto">
          <h1 className="text-2xl font-bold">Идеи</h1>
          <p className="text-sm text-muted">{ideas.length} всего · показано {list.length}</p>
        </div>
        <button className="btn btn-primary" onClick={() => setModal({})}>+ Идея</button>
      </header>

      <div className="space-y-3">
        <input className="input" placeholder="Поиск по идеям…" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="flex flex-wrap gap-1.5">
          {(["all", "high", "medium", "low"] as const).map((p) => (
            <button key={p} onClick={() => setPrio(p)}
              className={cn("rounded-full border px-3 py-1 text-xs font-medium transition", prio === p ? "border-accent bg-accent/20 text-accent-soft" : "border-line text-muted hover:text-white")}>
              {p === "all" ? "Все" : PRIORITY_LABEL[p]}
            </button>
          ))}
          {allTags.length > 0 && <span className="mx-1 self-center text-line">|</span>}
          {allTags.map((t) => (
            <button key={t} onClick={() => setTag(tag === t ? null : t)}
              className={cn("rounded-full border px-3 py-1 text-xs transition", tag === t ? "border-accent bg-accent/20 text-accent-soft" : "border-line text-muted hover:text-white")}>
              #{t}
            </button>
          ))}
        </div>
      </div>

      {list.length === 0 ? (
        <div className="card text-center text-sm text-muted">Ничего не найдено. Добавь идею кнопкой «+ Идея».</div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {list.map((i) => {
            const linked = streams.find((s) => s.id === i.streamId);
            return (
              <article key={i.id} onClick={() => setModal({ idea: i })} className="card cursor-pointer transition hover:border-accent/50">
                <div className="flex items-center justify-between gap-2">
                  <span className={cn("rounded-full px-2.5 py-0.5 text-xs font-medium", BADGE[i.priority])}>{PRIORITY_LABEL[i.priority]}</span>
                  <button className="text-muted transition hover:text-red-400" aria-label="Удалить"
                    onClick={(e) => { e.stopPropagation(); confirm("Удалить идею?") && setIdeas((p) => p.filter((x) => x.id !== i.id)); }}>✕</button>
                </div>
                <h3 className="mt-3 font-semibold leading-snug">{i.title}</h3>
                {i.description && <p className="mt-1 line-clamp-3 text-sm text-muted">{i.description}</p>}
                {i.tags.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    {i.tags.map((t) => (
                      <button key={t} className="rounded-full bg-white/5 px-2 py-0.5 text-xs text-muted hover:text-white" onClick={(e) => { e.stopPropagation(); setTag(t); }}>#{t}</button>
                    ))}
                  </div>
                )}
                {(linked || i.date) && (
                  <p className="mt-3 border-t border-line pt-2 text-xs text-accent-soft">
                    {linked ? `▶ ${linked.title} · ${new Date(linked.start).toLocaleDateString("ru-RU", { day: "numeric", month: "short" })}` : `📅 ${new Date(i.date!).toLocaleDateString("ru-RU", { day: "numeric", month: "long" })}`}
                  </p>
                )}
              </article>
            );
          })}
        </div>
      )}

      {modal && (
        <IdeaModal key={modal.idea?.id ?? "new"} idea={modal.idea} streams={streams} allTags={allTags} onSave={save}
          onDelete={modal.idea ? () => { setIdeas((p) => p.filter((x) => x.id !== modal.idea!.id)); setModal(null); } : undefined}
          onClose={() => setModal(null)} />
      )}
    </div>
  );
}
