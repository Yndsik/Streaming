import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0b0d12",
        card: "#12151c",
        line: "#1f2430",
        muted: "#8b93a7",
        accent: { DEFAULT: "#9146ff", soft: "#b388ff" },
        live: "#ef4444",
      },
    },
  },
  plugins: [],
};
export default config;
