"use client";

import { useState } from "react";
import type { Idea, Priority, Stream } from "@/lib/types";
import { PRIORITY_LABEL } from "@/lib/types";

export type IdeaDraft = Pick<Idea, "title" | "description" | "tags" | "priority" | "streamId" | "date">;

interface Props {
  idea?: Idea;
  streams: Stream[];
  allTags: string[];
  onSave: (d: IdeaDraft) => void;
  onDelete?: () => void;
  onClose: () => void;
}

const parseTags = (v: string) => [...new Set(v.split(/[,\n]/).map((t) => t.trim().replace(/^#/, "").toLowerCase()).filter(Boolean))];

export default function IdeaModal({ idea, streams, allTags, onSave, onDelete, onClose }: Props) {
  const [title, setTitle] = useState(idea?.title ?? "");
  const [description, setDescription] = useState(idea?.description ?? "");
  const [tags, setTags] = useState(idea?.tags.join(", ") ?? "");
  const [priority, setPriority] = useState<Priority>(idea?.priority ?? "medium");
  const [streamId, setStreamId] = useState(idea?.streamId ?? "");
  const [date, setDate] = useState(idea?.date ?? "");

  const sortedStreams = [...streams].sort((a, b) => +new Date(b.start) - +new Date(a.start));
  const currentTags = parseTags(tags);
  const addTag = (t: string) => !currentTags.includes(t) && setTags([...currentTags, t].join(", "));

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-sm sm:items-center sm:p-4" onClick={onClose}>
      <div className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-2xl border border-line bg-card p-5 sm:rounded-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-bold">{idea ? "Редактировать идею" : "Новая идея"}</h3>
          <button className="btn btn-ghost !px-2" onClick={onClose} aria-label="Закрыть">✕</button>
        </div>

        <div className="space-y-3">
          <input className="input" placeholder="Идея" value={title} onChange={(e) => setTitle(e.target.value)} autoFocus />
          <textarea className="input min-h-[90px] resize-y" placeholder="Описание (необязательно)" value={description} onChange={(e) => setDescription(e.target.value)} />

          <div>
            <input className="input" placeholder="Теги через запятую" value={tags} onChange={(e) => setTags(e.target.value)} />
            {allTags.filter((t) => !currentTags.includes(t)).length > 0 && (
              <div className="mt-2 flex flex-wrap gap-1.5">
                {allTags.filter((t) => !currentTags.includes(t)).slice(0, 10).map((t) => (
                  <button key={t} className="rounded-full border border-line px-2 py-0.5 text-xs text-muted hover:text-white" onClick={() => addTag(t)}>+ {t}</button>
                ))}
              </div>
            )}
          </div>

          <div>
            <p className="mb-1 text-xs text-muted">Приоритет</p>
            <div className="grid grid-cols-3 gap-2">
              {(Object.keys(PRIORITY_LABEL) as Priority[]).map((p) => (
                <button key={p} onClick={() => setPriority(p)}
                  className={`btn ${priority === p ? "!border-accent !bg-accent/20 text-accent-soft" : ""}`}>{PRIORITY_LABEL[p]}</button>
              ))}
            </div>
          </div>

          <label className="block text-xs text-muted">Привязать к стриму
            <select className="input mt-1" value={streamId} onChange={(e) => setStreamId(e.target.value)}>
              <option value="">— не привязано —</option>
              {sortedStreams.map((s) => (
                <option key={s.id} value={s.id}>
                  {new Date(s.start).toLocaleDateString("ru-RU", { day: "numeric", month: "short" })} · {s.title}
                </option>
              ))}
            </select>
          </label>

          <label className="block text-xs text-muted">Или к дате
            <input className="input mt-1" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </label>
        </div>

        <div className="mt-5 flex gap-2">
          <button className="btn btn-primary" disabled={!title.trim()} onClick={() => onSave({
            title: title.trim(), description: description.trim() || undefined, tags: parseTags(tags), priority,
            streamId: streamId || undefined, date: date || undefined,
          })}>Сохранить</button>
          {idea && onDelete && (
            <button className="btn btn-ghost ml-auto text-red-400 hover:!text-red-300" onClick={() => confirm("Удалить идею?") && onDelete()}>Удалить</button>
          )}
        </div>
      </div>
    </div>
  );
}
