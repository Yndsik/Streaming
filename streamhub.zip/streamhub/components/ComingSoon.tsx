export default function ComingSoon({ title }: { title: string }) {
  return (
    <div>
      <h1 className="text-2xl font-bold">{title}</h1>
      <div className="card mt-6 text-muted">Раздел в разработке — будет следующим шагом.</div>
    </div>
  );
}
