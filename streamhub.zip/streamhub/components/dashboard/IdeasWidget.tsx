"use client";

import Link from "next/link";
import { useState } from "react";
import { useStore } from "@/lib/store";
import { PRIORITY_LABEL, type Priority } from "@/lib/types";
import { uid } from "@/lib/utils";

const ORDER: Record<Priority, number> = { high: 0, medium: 1, low: 2 };
const DOT: Record<Priority, string> = { high: "bg-red-500", medium: "bg-amber-400", low: "bg-zinc-500" };

export default function IdeasWidget() {
  const { ready, ideas, setIdeas } = useStore();
  const [title, setTitle] = useState("");

  const add = () => {
    const t = title.trim();
    if (!t) return;
    setIdeas((p) => [{ id: uid(), title: t, tags: [], priority: "medium", createdAt: new Date().toISOString() }, ...p]);
    setTitle("");
  };

  const top = [...ideas].sort((a, b) => ORDER[a.priority] - ORDER[b.priority] || +new Date(b.createdAt) - +new Date(a.createdAt)).slice(0, 5);

  return (
    <section className="card">
      <div className="flex items-center justify-between">
        <h2 className="h-section">Идеи</h2>
        <Link href="/ideas" className="text-xs text-accent-soft hover:underline">Все идеи →</Link>
      </div>

      <div className="mt-3 flex gap-2">
        <input className="input" placeholder="Быстрая идея…" value={title} onChange={(e) => setTitle(e.target.value)} onKeyDown={(e) => e.key === "Enter" && add()} />
        <button className="btn btn-primary" onClick={add} aria-label="Добавить идею">+</button>
      </div>

      {!ready ? (
        <div className="mt-4 h-24 animate-pulse rounded-xl bg-white/5" />
      ) : top.length === 0 ? (
        <p className="mt-4 text-sm text-muted">Идей пока нет.</p>
      ) : (
        <ul className="mt-4 space-y-2">
          {top.map((i) => (
            <li key={i.id} className="group flex items-center gap-3 rounded-xl border border-line bg-bg/50 px-3 py-2.5">
              <span title={PRIORITY_LABEL[i.priority]} className={`h-2.5 w-2.5 shrink-0 rounded-full ${DOT[i.priority]}`} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm">{i.title}</p>
                {i.tags.length > 0 && <p className="truncate text-xs text-muted">{i.tags.map((t) => `#${t}`).join(" ")}</p>}
              </div>
              <button className="text-muted transition hover:text-red-400 md:opacity-0 md:group-hover:opacity-100" onClick={() => setIdeas((p) => p.filter((x) => x.id !== i.id))} aria-label="Удалить">✕</button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
