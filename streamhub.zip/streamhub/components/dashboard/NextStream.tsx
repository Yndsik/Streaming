"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useStore } from "@/lib/store";
import { STATUS_LABEL } from "@/lib/types";
import { countdown, fmtDateTime, fromLocalInput, toLocalInput } from "@/lib/utils";

export default function NextStream() {
  const { ready, streams, addStream, updateStream, startStream, endStream, postpone } = useStore();
  const [, tick] = useState(0);
  const [postponing, setPostponing] = useState(false);
  const [when, setWhen] = useState("");
  const [form, setForm] = useState({ title: "", game: "", start: "" });

  useEffect(() => {
    const t = setInterval(() => tick((n) => n + 1), 30_000);
    return () => clearInterval(t);
  }, []);

  if (!ready) return <div className="card h-48 animate-pulse" />;

  const now = Date.now();
  const planned = streams
    .filter((s) => s.status === "planned")
    .sort((a, b) => +new Date(a.start) - +new Date(b.start));
  const next = streams.find((s) => s.status === "live") ?? planned.find((s) => +new Date(s.start) >= now - 36e5) ?? planned[0];

  if (!next) {
    return (
      <section className="card">
        <h2 className="h-section">Ближайший стрим</h2>
        <p className="mt-3 text-sm text-muted">Пока ничего не запланировано. Создай первый стрим:</p>
        <div className="mt-4 grid gap-2 sm:grid-cols-[1fr_1fr_auto_auto]">
          <input className="input" placeholder="Название" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <input className="input" placeholder="Игра (необязательно)" value={form.game} onChange={(e) => setForm({ ...form, game: e.target.value })} />
          <input className="input" type="datetime-local" value={form.start} onChange={(e) => setForm({ ...form, start: e.target.value })} />
          <button
            className="btn btn-primary"
            disabled={!form.title.trim() || !form.start}
            onClick={() => {
              addStream({ title: form.title.trim(), game: form.game.trim() || undefined, start: fromLocalInput(form.start) });
              setForm({ title: "", game: "", start: "" });
            }}
          >
            Создать
          </button>
        </div>
      </section>
    );
  }

  const live = next.status === "live";
  const shift = (ms: number) => postpone(next.id, new Date(new Date(next.start).getTime() + ms).toISOString());

  return (
    <section className="card relative overflow-hidden">
      <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-accent/20 blur-3xl" />
      <div className="relative">
        <div className="flex items-center justify-between gap-3">
          <h2 className="h-section">{live ? "Сейчас в эфире" : "Ближайший стрим"}</h2>
          <span className={`rounded-full px-2.5 py-1 text-xs font-medium ${live ? "bg-live/20 text-live" : "bg-white/5 text-muted"}`}>
            {live && <span className="mr-1.5 inline-block h-1.5 w-1.5 animate-pulse rounded-full bg-live" />}
            {STATUS_LABEL[next.status]}
          </span>
        </div>

        <h3 className="mt-3 text-xl font-bold sm:text-2xl">{next.title}</h3>
        <p className="mt-1 text-sm text-muted">
          {next.game && <span className="text-zinc-300">{next.game} · </span>}
          {fmtDateTime(next.start)}
          {!live && <span className="text-accent-soft"> · {countdown(next.start)}</span>}
        </p>

        <div className="mt-5 flex flex-wrap gap-2">
          {!live ? (
            <button className="btn btn-primary" onClick={() => startStream(next.id)}>▶ Начать стрим</button>
          ) : (
            <button className="btn btn-live" onClick={() => endStream(next.id)}>■ Закончить стрим</button>
          )}
          {!live && (
            <button className="btn" onClick={() => { setWhen(toLocalInput(next.start)); setPostponing((v) => !v); }}>
              ⏭ Перенести
            </button>
          )}
          <Link href="/schedule" className="btn btn-ghost">Всё расписание →</Link>
        </div>

        {postponing && !live && (
          <div className="mt-3 flex flex-wrap items-center gap-2 rounded-xl border border-line bg-bg/60 p-3">
            <button className="btn" onClick={() => { shift(36e5); setPostponing(false); }}>+1 час</button>
            <button className="btn" onClick={() => { shift(864e5); setPostponing(false); }}>+1 день</button>
            <input className="input !w-auto" type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} />
            <button className="btn btn-primary" disabled={!when} onClick={() => { postpone(next.id, fromLocalInput(when)); setPostponing(false); }}>
              Сохранить
            </button>
          </div>
        )}

        <textarea
          className="input mt-4 min-h-[84px] resize-y"
          placeholder="Заметки к стриму…"
          value={next.notes}
          onChange={(e) => updateStream(next.id, { notes: e.target.value })}
        />
      </div>
    </section>
  );
}
