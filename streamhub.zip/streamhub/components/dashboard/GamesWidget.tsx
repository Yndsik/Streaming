/* eslint-disable @next/next/no-img-element */
"use client";

import Link from "next/link";
import { useStore } from "@/lib/store";
import { formatOnline, steamCover } from "@/lib/utils";

export default function GamesWidget() {
  const { ready, games } = useStore();
  const top = games
    .filter((g) => g.online != null)
    .sort((a, b) => (b.online ?? 0) - (a.online ?? 0))
    .slice(0, 5);

  return (
    <section className="card">
      <div className="flex items-center justify-between">
        <h2 className="h-section">Популярные игры</h2>
        <Link href="/games" className="text-xs text-accent-soft hover:underline">Каталог →</Link>
      </div>

      {!ready ? (
        <div className="mt-4 h-40 animate-pulse rounded-xl bg-white/5" />
      ) : (
        <ul className="mt-4 space-y-2">
          {top.map((g, idx) => {
            const cover = g.cover ?? steamCover(g.appId);
            return (
              <li key={g.id} className="flex items-center gap-3 rounded-xl border border-line bg-bg/50 p-2">
                <span className="w-5 text-center text-xs text-muted">{idx + 1}</span>
                {cover ? (
                  <img src={cover} alt="" loading="lazy" className="h-10 w-[86px] shrink-0 rounded-lg object-cover" onError={(e) => (e.currentTarget.style.visibility = "hidden")} />
                ) : (
                  <div className="h-10 w-[86px] shrink-0 rounded-lg bg-white/5" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{g.title}</p>
                  <p className="text-xs text-muted">
                    <span className="mr-1 inline-block h-1.5 w-1.5 rounded-full bg-emerald-400" />
                    {formatOnline(g.online)} онлайн
                  </p>
                </div>
                <a href={g.steamUrl} target="_blank" rel="noopener noreferrer" className="btn btn-ghost !px-2.5 !py-1.5 text-xs">Steam ↗</a>
              </li>
            );
          })}
        </ul>
      )}
      <p className="mt-3 text-[11px] text-muted">Онлайн — демо-значения, живые данные подключим в каталоге.</p>
    </section>
  );
}
