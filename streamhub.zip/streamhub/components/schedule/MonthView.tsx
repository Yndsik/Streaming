import type { Stream } from "@/lib/types";
import { cn, monthGrid, sameDay, WEEKDAYS } from "@/lib/utils";
import { STATUS_DOT } from "./status";

interface Props {
  cursor: Date;
  selected: Date;
  byDay: Map<string, Stream[]>;
  onSelect: (d: Date) => void;
  onOpen: (s: Stream) => void;
}

export default function MonthView({ cursor, selected, byDay, onSelect, onOpen }: Props) {
  const days = monthGrid(cursor);
  const today = new Date();

  return (
    <div className="card !p-2 sm:!p-3">
      <div className="grid grid-cols-7 pb-2 text-center text-xs text-muted">
        {WEEKDAYS.map((d) => <div key={d}>{d}</div>)}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {days.map((d) => {
          const list = byDay.get(d.toDateString()) ?? [];
          const inMonth = d.getMonth() === cursor.getMonth();
          return (
            <div key={d.toISOString()} onClick={() => onSelect(d)}
              className={cn("min-h-[56px] cursor-pointer rounded-lg border p-1 transition sm:min-h-[96px] sm:p-1.5",
                sameDay(d, selected) ? "border-accent bg-accent/10" : "border-line hover:bg-white/5", !inMonth && "opacity-40")}>
              <div className={cn("mb-1 text-xs", sameDay(d, today) ? "grid h-5 w-5 place-items-center rounded-full bg-accent font-bold text-white" : "text-muted")}>
                {d.getDate()}
              </div>
              {/* mobile: dots */}
              <div className="flex flex-wrap gap-0.5 sm:hidden">
                {list.slice(0, 4).map((s) => <span key={s.id} className={cn("h-1.5 w-1.5 rounded-full", STATUS_DOT[s.status])} />)}
              </div>
              {/* desktop: chips */}
              <div className="hidden space-y-0.5 sm:block">
                {list.slice(0, 3).map((s) => (
                  <button key={s.id} onClick={(e) => { e.stopPropagation(); onOpen(s); }}
                    className="flex w-full items-center gap-1 truncate rounded bg-white/5 px-1 py-0.5 text-left text-[11px] hover:bg-white/10">
                    <span className={cn("h-1.5 w-1.5 shrink-0 rounded-full", STATUS_DOT[s.status])} />
                    <span className="truncate">{s.title}</span>
                  </button>
                ))}
                {list.length > 3 && <p className="px-1 text-[10px] text-muted">+{list.length - 3} ещё</p>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
