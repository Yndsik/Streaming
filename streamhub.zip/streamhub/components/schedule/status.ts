import type { StreamStatus } from "@/lib/types";

export const STATUS_CARD: Record<StreamStatus, string> = {
  planned: "border-accent/40 bg-accent/10",
  live: "border-live/50 bg-live/10",
  done: "border-emerald-500/30 bg-emerald-500/10",
  cancelled: "border-line bg-white/5 opacity-60",
};

export const STATUS_DOT: Record<StreamStatus, string> = {
  planned: "bg-accent",
  live: "bg-live",
  done: "bg-emerald-500",
  cancelled: "bg-zinc-500",
};
