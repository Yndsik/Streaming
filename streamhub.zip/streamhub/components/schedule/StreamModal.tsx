"use client";

import { useState } from "react";
import type { Stream, StreamStatus } from "@/lib/types";
import { STATUS_LABEL } from "@/lib/types";
import { fromLocalInput, toLocalInput } from "@/lib/utils";

export type StreamDraft = Pick<Stream, "title" | "game" | "start" | "durationMin" | "status" | "notes">;

interface Props {
  stream?: Stream;
  defaultDate?: Date;
  gameTitles: string[];
  onSave: (d: StreamDraft) => void;
  onDelete?: () => void;
  onClose: () => void;
}

export default function StreamModal({ stream, defaultDate, gameTitles, onSave, onDelete, onClose }: Props) {
  const initialStart = stream?.start ?? (() => { const d = new Date(defaultDate ?? new Date()); d.setHours(19, 0, 0, 0); return d.toISOString(); })();
  const [title, setTitle] = useState(stream?.title ?? "");
  const [game, setGame] = useState(stream?.game ?? "");
  const [start, setStart] = useState(toLocalInput(initialStart));
  const [duration, setDuration] = useState(stream?.durationMin ?? 180);
  const [status, setStatus] = useState<StreamStatus>(stream?.status ?? "planned");
  const [notes, setNotes] = useState(stream?.notes ?? "");

  const build = (st: StreamStatus = status): StreamDraft => ({
    title: title.trim(), game: game.trim() || undefined, start: fromLocalInput(start), durationMin: Number(duration) || 60, status: st, notes,
  });
  const valid = title.trim() && start;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 backdrop-blur-sm sm:items-center sm:p-4" onClick={onClose}>
      <div className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-2xl border border-line bg-card p-5 sm:rounded-2xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-lg font-bold">{stream ? "Редактировать стрим" : "Новый стрим"}</h3>
          <button className="btn btn-ghost !px-2" onClick={onClose} aria-label="Закрыть">✕</button>
        </div>

        <div className="space-y-3">
          <input className="input" placeholder="Название" value={title} onChange={(e) => setTitle(e.target.value)} autoFocus />
          <input className="input" list="games-list" placeholder="Игра" value={game} onChange={(e) => setGame(e.target.value)} />
          <datalist id="games-list">{gameTitles.map((g) => <option key={g} value={g} />)}</datalist>

          <div className="grid grid-cols-2 gap-3">
            <label className="text-xs text-muted">Начало
              <input className="input mt-1" type="datetime-local" value={start} onChange={(e) => setStart(e.target.value)} />
            </label>
            <label className="text-xs text-muted">Длительность, мин
              <input className="input mt-1" type="number" min={15} step={15} value={duration} onChange={(e) => setDuration(Number(e.target.value))} />
            </label>
          </div>

          <label className="block text-xs text-muted">Статус
            <select className="input mt-1" value={status} onChange={(e) => setStatus(e.target.value as StreamStatus)}>
              {(Object.keys(STATUS_LABEL) as StreamStatus[]).map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
            </select>
          </label>

          <label className="block text-xs text-muted">Заметки
            <textarea className="input mt-1 min-h-[110px] resize-y" placeholder="План, темы, итоги стрима…" value={notes} onChange={(e) => setNotes(e.target.value)} />
          </label>
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <button className="btn btn-primary" disabled={!valid} onClick={() => onSave(build())}>Сохранить</button>
          {stream && status !== "done" && (
            <button className="btn" disabled={!valid} onClick={() => onSave(build("done"))}>✓ Завершён</button>
          )}
          {stream && onDelete && (
            <button className="btn btn-ghost ml-auto text-red-400 hover:!text-red-300" onClick={() => confirm("Удалить стрим?") && onDelete()}>Удалить</button>
          )}
        </div>
      </div>
    </div>
  );
}
