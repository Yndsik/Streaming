import type { Stream } from "@/lib/types";
import { addDays, cn, sameDay, startOfWeek, WEEKDAYS } from "@/lib/utils";
import StreamItem from "./StreamItem";

interface Props {
  cursor: Date;
  byDay: Map<string, Stream[]>;
  onAdd: (d: Date) => void;
  onOpen: (s: Stream) => void;
}

export default function WeekView({ cursor, byDay, onAdd, onOpen }: Props) {
  const start = startOfWeek(cursor);
  const today = new Date();

  return (
    <div className="grid gap-2 lg:grid-cols-7">
      {Array.from({ length: 7 }, (_, i) => addDays(start, i)).map((d, i) => {
        const list = byDay.get(d.toDateString()) ?? [];
        const isToday = sameDay(d, today);
        return (
          <div key={i} className={cn("rounded-2xl border bg-card p-2.5", isToday ? "border-accent/60" : "border-line")}>
            <div className="mb-2 flex items-center justify-between">
              <div className="text-sm">
                <span className={cn("font-semibold", isToday && "text-accent-soft")}>{WEEKDAYS[i]}</span>
                <span className="ml-1.5 text-muted">{d.getDate()}.{String(d.getMonth() + 1).padStart(2, "0")}</span>
              </div>
              <button className="btn btn-ghost !px-2 !py-0.5" onClick={() => onAdd(d)} aria-label="Добавить стрим">+</button>
            </div>
            <div className="space-y-2">
              {list.length === 0 ? <p className="py-1 text-xs text-muted/60">Свободно</p> : list.map((s) => <StreamItem key={s.id} stream={s} onClick={() => onOpen(s)} />)}
            </div>
          </div>
        );
      })}
    </div>
  );
}
