import type { Stream } from "@/lib/types";
import { STATUS_LABEL } from "@/lib/types";
import { cn, fmtTime } from "@/lib/utils";
import { STATUS_CARD, STATUS_DOT } from "./status";

export default function StreamItem({ stream, onClick }: { stream: Stream; onClick: () => void }) {
  return (
    <button onClick={onClick} className={cn("w-full rounded-xl border p-2.5 text-left transition hover:brightness-125", STATUS_CARD[stream.status])}>
      <div className="flex items-center gap-2 text-xs text-muted">
        <span className={cn("h-2 w-2 rounded-full", STATUS_DOT[stream.status])} />
        <span>{fmtTime(stream.start)}</span>
        <span className="ml-auto">{STATUS_LABEL[stream.status]}</span>
      </div>
      <p className={cn("mt-1 text-sm font-medium leading-snug", stream.status === "cancelled" && "line-through")}>{stream.title}</p>
      {stream.game && <p className="truncate text-xs text-muted">{stream.game}</p>}
      {stream.notes && <p className="mt-1 truncate text-xs text-zinc-400">📝 {stream.notes}</p>}
    </button>
  );
}
