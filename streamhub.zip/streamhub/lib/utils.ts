export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

export const cn = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(" ");

export const fmtDateTime = (iso: string) =>
  new Date(iso).toLocaleString("ru-RU", { weekday: "short", day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" });

const pad = (n: number) => String(n).padStart(2, "0");

export const toLocalInput = (iso: string) => {
  const d = new Date(iso);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

export const fromLocalInput = (v: string) => new Date(v).toISOString();

export function countdown(iso: string, now = Date.now()) {
  const diff = new Date(iso).getTime() - now;
  const abs = Math.abs(diff);
  const d = Math.floor(abs / 864e5);
  const h = Math.floor((abs % 864e5) / 36e5);
  const m = Math.floor((abs % 36e5) / 6e4);
  const text = [d && `${d} д`, (d || h) && `${h} ч`, `${m} мин`].filter(Boolean).join(" ");
  return diff >= 0 ? `через ${text}` : `${text} назад`;
}

export const steamCover = (appId?: number) =>
  appId ? `https://cdn.akamai.steamstatic.com/steam/apps/${appId}/header.jpg` : undefined;

export const formatOnline = (n?: number) => (n == null ? "—" : n.toLocaleString("ru-RU"));

// ---- Даты для календаря ----
export const startOfDay = (d: Date) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
export const addDays = (d: Date, n: number) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
export const startOfWeek = (d: Date) => addDays(startOfDay(d), -((d.getDay() + 6) % 7)); // понедельник
export const sameDay = (a: Date, b: Date) => a.toDateString() === b.toDateString();
export const monthGrid = (d: Date) => {
  const start = startOfWeek(new Date(d.getFullYear(), d.getMonth(), 1));
  return Array.from({ length: 42 }, (_, i) => addDays(start, i));
};
export const fmtTime = (iso: string) => new Date(iso).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
export const WEEKDAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];
