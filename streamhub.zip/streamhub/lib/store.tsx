"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type Dispatch, type ReactNode, type SetStateAction } from "react";
import type { Game, Idea, Stream } from "./types";
import { SEED_GAMES, SEED_IDEAS } from "./seed";
import { uid } from "./utils";

function usePersisted<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(initial);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(key);
      if (raw) setValue(JSON.parse(raw) as T);
    } catch {}
    setReady(true);
  }, [key]);

  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {}
  }, [key, value, ready]);

  return [value, setValue, ready] as const;
}

interface Store {
  ready: boolean;
  streams: Stream[];
  ideas: Idea[];
  games: Game[];
  setStreams: Dispatch<SetStateAction<Stream[]>>;
  setIdeas: Dispatch<SetStateAction<Idea[]>>;
  setGames: Dispatch<SetStateAction<Game[]>>;
  addStream: (s: Partial<Stream> & Pick<Stream, "title" | "start">) => Stream;
  updateStream: (id: string, patch: Partial<Stream>) => void;
  startStream: (id: string) => void;
  endStream: (id: string) => void;
  postpone: (id: string, newStartIso: string) => void;
}

const Ctx = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [streams, setStreams, r1] = usePersisted<Stream[]>("sh:streams", []);
  const [ideas, setIdeas, r2] = usePersisted<Idea[]>("sh:ideas", SEED_IDEAS);
  const [games, setGames, r3] = usePersisted<Game[]>("sh:games", SEED_GAMES);

  const updateStream = useCallback((id: string, patch: Partial<Stream>) => setStreams((p) => p.map((s) => (s.id === id ? { ...s, ...patch } : s))), [setStreams]);

  const value = useMemo<Store>(
    () => ({
      ready: r1 && r2 && r3,
      streams, ideas, games, setStreams, setIdeas, setGames,
      addStream: (s) => {
        const stream: Stream = { id: uid(), durationMin: 180, status: "planned", notes: "", ...s };
        setStreams((p) => [...p, stream]);
        return stream;
      },
      updateStream,
      startStream: (id) => updateStream(id, { status: "live" }),
      endStream: (id) => updateStream(id, { status: "done" }),
      postpone: (id, iso) => updateStream(id, { start: iso, status: "planned" }),
    }),
    [r1, r2, r3, streams, ideas, games, setStreams, setIdeas, setGames, updateStream]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStore must be used inside StoreProvider");
  return ctx;
}
