export type StreamStatus = "planned" | "live" | "done" | "cancelled";
export type Priority = "low" | "medium" | "high";
export type GameCategory = "popular" | "upcoming" | "indie" | "custom";
export type GameStatus = "none" | "want" | "streamed";

export interface Stream {
  id: string;
  title: string;
  game?: string;
  start: string; // ISO
  durationMin: number;
  status: StreamStatus;
  notes: string;
}

export interface Idea {
  id: string;
  title: string;
  description?: string;
  tags: string[];
  priority: Priority;
  streamId?: string;
  date?: string; // ISO date
  createdAt: string;
}

export interface Game {
  id: string;
  title: string;
  appId?: number; // Steam app id
  cover?: string;
  genres: string[];
  description: string;
  steamUrl: string;
  category: GameCategory;
  status: GameStatus;
  online?: number;
  releaseDate?: string;
}

export const STATUS_LABEL: Record<StreamStatus, string> = {
  planned: "Запланирован",
  live: "В эфире",
  done: "Завершён",
  cancelled: "Отменён",
};

export const PRIORITY_LABEL: Record<Priority, string> = {
  low: "Низкий",
  medium: "Средний",
  high: "Высокий",
};
