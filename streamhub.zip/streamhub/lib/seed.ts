import type { Game, Idea } from "./types";
import { uid } from "./utils";

const steam = (id: number) => `https://store.steampowered.com/app/${id}`;

type G = Omit<Game, "id" | "steamUrl" | "status"> & { appId: number; status?: Game["status"] };
const mk = (g: G): Game => ({ ...g, id: `steam-${g.appId}`, steamUrl: steam(g.appId), status: g.status ?? "none" });

// Онлайн — примерные демо-значения. Позже можно подключить Steam Web API через route handler.
export const SEED_GAMES: Game[] = [
  mk({ appId: 730, title: "Counter-Strike 2", genres: ["Шутер", "Тактика"], category: "popular", online: 1_450_000, description: "Командный тактический шутер — вечная классика соревновательных стримов." }),
  mk({ appId: 570, title: "Dota 2", genres: ["MOBA", "Стратегия"], category: "popular", online: 680_000, description: "Глубокая MOBA с огромным комьюнити и стабильным зрителем." }),
  mk({ appId: 1172470, title: "Apex Legends", genres: ["Battle Royale", "Шутер"], category: "popular", online: 190_000, description: "Динамичная королевская битва с героями и уникальными способностями." }),
  mk({ appId: 578080, title: "PUBG: BATTLEGROUNDS", genres: ["Battle Royale", "Шутер"], category: "popular", online: 420_000, description: "Тактическая королевская битва на больших картах." }),
  mk({ appId: 1086940, title: "Baldur's Gate 3", genres: ["RPG", "Пошаговая"], category: "popular", online: 85_000, description: "Эпическая CRPG по D&D: выборы, юмор и неожиданные последствия." }),
  mk({ appId: 3527290, title: "PEAK", genres: ["Кооператив", "Выживание"], category: "indie", online: 40_000, description: "Кооперативное восхождение на гору, идеально для весёлых стримов с чатом." }),
  mk({ appId: 3164500, title: "Schedule I", genres: ["Симулятор", "Кооператив"], category: "indie", online: 30_000, description: "Инди-симулятор бизнеса в песочнице с кооперативом." }),
  mk({ appId: 2379780, title: "Balatro", genres: ["Рогалик", "Карточная"], category: "indie", online: 12_000, description: "Покерный рогалик, который сложно отпустить." }),
  mk({ appId: 1145350, title: "Hades II", genres: ["Рогалик", "Экшен"], category: "indie", online: 20_000, description: "Продолжение культового рогалика от Supergiant Games." }),
  mk({ appId: 1030300, title: "Hollow Knight: Silksong", genres: ["Метроидвания", "Платформер"], category: "upcoming", description: "Долгожданное продолжение Hollow Knight — проверьте актуальную дату в Steam." }),
  mk({ appId: 413150, title: "Stardew Valley", genres: ["Симулятор", "Инди"], category: "indie", online: 25_000, status: "want", description: "Уютная ферма для спокойных вечерних стримов." }),
];

export const SEED_IDEAS: Idea[] = [
  { id: uid(), title: "Челлендж: пройти игру без смертей", tags: ["челлендж"], priority: "high", createdAt: new Date().toISOString() },
  { id: uid(), title: "Стрим с вебкой Q&A на 1 час", tags: ["общение"], priority: "medium", createdAt: new Date().toISOString() },
  { id: uid(), title: "Нарезать клипы недели в шортсы", tags: ["клипы"], priority: "low", createdAt: new Date().toISOString() },
];
