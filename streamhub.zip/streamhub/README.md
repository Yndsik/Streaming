# StreamHub
```bash
npm install
npm run dev   # http://localhost:3000
```
Все данные хранятся в localStorage браузера.
